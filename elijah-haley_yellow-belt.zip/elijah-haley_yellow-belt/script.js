function change(_id){
    _id.src="succulents-2.jpg";
}

function changeBack(_id){
    _id.src="succulents-1.jpg";
}

function disappear(_id){
    document.querySelector(_id).remove();
}